package org.mycompany;

import javax.jws.WebMethod;
import javax.jws.WebResult;
import javax.xml.ws.RequestWrapper;
import javax.xml.ws.ResponseWrapper;

public interface Service {
	
	@WebMethod
	@RequestWrapper(localName = "input", targetNamespace = "http://mycompany.org", className = "org.mycompany.Input")
	@ResponseWrapper(localName = "inputResponse", targetNamespace = "http://mycompany.org", className = "org.mycompany.Output")
	@WebResult(name = "status", targetNamespace = "")
	Output input(final Input p0);

}
